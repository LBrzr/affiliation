interface User {
    _id: number;
    name: string;
    email: string;
};

export default User;