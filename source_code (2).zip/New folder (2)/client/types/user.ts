interface User {
    _id: number;
    name: string;
    email: string;
    balance: number;
};

export default User;